public class TaillesNonConcordantesException extends Exception{
    public TaillesNonConcordantesException() {
    }
    public TaillesNonConcordantesException(String s) {
    }
}
