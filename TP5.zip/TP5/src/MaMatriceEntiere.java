import java.util.concurrent.Callable;

public class MaMatriceEntiere{

    private int lignes;
    private int colonnes;
    private  int m[][];
    public MaMatriceEntiere(int lignes, int colonnes, int p) {
        this.lignes = lignes;
        this.colonnes = colonnes;
          m=new int[lignes][colonnes];
     if (p==0){
         for (int i = 0; i <lignes ; i++) {
             for (int j = 0; j <colonnes ; j++) {
                 m[i][j]=0;
             }

         }
     }
     else if(p==1){
         for (int i = 0; i <lignes ; i++) {
             for (int j = 0; j <colonnes ; j++) {
                 m[i][j]=0+(int)(Math.random()*(10))+1 ;//générateur des variables aléatoires
             }
         }
     }
    }

    public int getElement(int i,int j){
        return m[i][j];
    }
    public void setElement(int i,int j,int val){
        m[i][j]=val;
    }


    public int getLignes() {
        return lignes;
    }
    public int getColonnes() {
        return colonnes;
    }
    public void printMatrice() {
        for (int i = 0; i < this.getLignes(); i++) {
            for (int j = 0; j < this.getColonnes(); j++) {
                System.out.print(this.getElement(i,j));
                System.out.print("|"); }
            System.out.println(" "); }
    }
    public static int produitUneligneColonne(MaMatriceEntiere m1,int i,MaMatriceEntiere m2,int j)
            throws TaillesNonConcordantesException{
          if (m2.getLignes() != m1.getColonnes())
              throw new TaillesNonConcordantesException();
              int s = 0;
              for (int k = 0; k < m2.getLignes(); k++) {
                      s += m1.m[i][k] * m2.m[k][j];
              }
              return s;
          }
}

