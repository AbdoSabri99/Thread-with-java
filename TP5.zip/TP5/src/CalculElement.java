import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CalculElement implements Runnable, Callable<Integer> {
    private MaMatriceEntiere m1;
    private MaMatriceEntiere m2;
    private int i;
    private  int j;
    private static MaMatriceEntiere m;
    public CalculElement(MaMatriceEntiere m1, MaMatriceEntiere m2,int i,int j) {
        this.m1 = m1;
        this.m2 = m2;
        this.i=i;
        this.j=j;
        if(m==null)
            m=new MaMatriceEntiere(m1.getLignes(),m2.getColonnes(),0);
    }
    public void run() {
        try {
            Future<Integer> f= Executors.newFixedThreadPool(4).submit((Callable<Integer>)
                    new CalculElement(m1,m2,i,j));
            m.setElement(i, j, f.get());
           // System.out.println("Fin de Calcul:");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }


    public static MaMatriceEntiere getM() {
        return m;
    }

    @Override
    public Integer call() throws Exception {
        return MaMatriceEntiere.produitUneligneColonne(m1, i, m2, j);
    }
}
