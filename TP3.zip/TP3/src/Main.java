public class Main {
    public static void main(String[] args) throws InterruptedException {
        MdseObjet o1=new MdseObjet(5,10);  MdseObjet o2=new MdseObjet(1,10);MdseObjet o3=new MdseObjet(3,10);
        MdseObjet o4=new MdseObjet(3,10);MdseObjet o5=new MdseObjet(3,10);MdseObjet o6=new MdseObjet(3,10);
        MdseObjet o7=new MdseObjet(3,10); MdseStock s=new MdseStock();
        s.toFill(o1); s.toFill(o2); s.toFill(o3);s.toFill(o4);s.toFill(o5); s.toFill(o6); s.toFill(o7);
        System.out.println(s.getMdse());
        Chargeur c=new Chargeur(s);
        Chariot ch=new Chariot(20);
        Thread t1=new Thread("T1") {
            @Override
            public void run() {
                try {
                    c.Empiler(ch);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } }};
        Dechargeur d=new Dechargeur(s);
        Thread t2=new Thread("T2") {
            @Override
            public void run() {
                try {
                    d.decharger(ch);
                } catch (InterruptedException e) {
                    e.printStackTrace(); }  }  };
        t1.start();t2.start();t1.join(); t2.join();
        System.out.println(ch.getCh());
    }}

