public class Chargeur{
    private MdseStock s;
    public Chargeur(MdseStock s){
        this.s=s;
    }
    public void Empiler(Chariot c) throws InterruptedException {
        synchronized (c) {
                while (!s.isEmpty()) {
                        double p=0;
                        int i=s.getMdse().size()-1;
                        do{
                            if(p+s.getMdse().get(i).getPoid()<=c.getCapmax()) {
                                p += s.getMdse().get(i).getPoid();
                                System.out.println("mdse added " + s.getMdse().get(i));
                                c.getCh().add(s.extract(i));
                            }
                            i--;
                        }while (i>=0);
                    System.out.println("chargement términé|"+c.getCh()+"|total poid:"+c.poid());
                    c.notify();
                    System.out.println("hops!!,chargeur en attente du dechargement");
                    c.wait();
                }
                c.notify();
        }
    }
}

