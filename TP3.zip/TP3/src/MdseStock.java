import java.util.ArrayList;

public class MdseStock {
    //array for stock the mdse
    private ArrayList<MdseObjet> mdse=new ArrayList<MdseObjet>();
    //Method for add a mdse to stock
    public void toFill(MdseObjet m){
        mdse.add(m);
    }
    //method to see if the stock is empty or not
    public  boolean isEmpty(){
        return mdse.isEmpty();
    }

    //method to extract a mdse from stock
    public MdseObjet extract(int i){
        MdseObjet o = this.mdse.get(i);
        mdse.remove(i);//remove a object and return it;
        return o;
    }
    public ArrayList<MdseObjet> getMdse() {
        return mdse;
    }

    public void setMdse(ArrayList<MdseObjet> mdse) {
        this.mdse = mdse;
    }


}
