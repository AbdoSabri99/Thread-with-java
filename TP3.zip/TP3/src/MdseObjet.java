public class MdseObjet {
    private double poid;//this is masse of product
    public MdseObjet(int min,int max){
        this.poid=min+(int)(Math.random()*(max-min))+1;//random values for poid
    }
    public double getPoid() {
        return poid;
    }
}
