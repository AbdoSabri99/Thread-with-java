public class Dechargeur {
    private MdseStock s;

    public Dechargeur(MdseStock s) {
        this.s = s;
    }

    public  void decharger(Chariot c) throws InterruptedException {
        synchronized (c){
           while (!s.isEmpty()) {
                if (c.isEmpty()) {
                    System.out.println("hops!!,dechargeur en attente du chargement");
                    c.wait();
                }
                while (!c.isEmpty()) {
                    c.decharger();
                    System.out.println("Dechargement términé|" + c.getCh());
                }
                c.notify();
           }
        }
    }
}
