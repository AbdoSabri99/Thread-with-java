import java.util.ArrayList;
public class Chariot {
    private int capmax;
    private ArrayList<MdseObjet> ch=new ArrayList<MdseObjet>();
    public Chariot(int capmax){
        this.capmax=capmax;
    }
    public ArrayList<MdseObjet> getCh() {
        return ch;
    }
    public int getCapmax() {
        return capmax;
    }
    //poid of the mdse i, chariot
    public double poid(){
        double p=0;
        for (int i = 0; i <ch.size() ; i++) {
            p+=ch.get(i).getPoid();
        }
        return p;
    }
    //see when the Chariot is plein
    public boolean isPlein(){
        return poid()==capmax;
    }
    //see when the chariot is empty
    public boolean isEmpty(){
        return ch.isEmpty();
    }
    public void decharger(){
        while (!isEmpty())
           ch.remove(0);
    }
}
