import java.util.Random;
public class Servant implements  Runnable{
    private Requete r;

    public Servant(Requete r) { this.r = r;
    }
    @Override
    public void run() {
        if(r.getEmiteur().getId() % 3 != 0){
            int time = new Random().nextInt((5000 - 600) + 1) + 600;
            System.out.println(r.getEmiteur().getId()+" waiting for :" + time + "ms");
            try {
                Thread.sleep(time);
            } catch (InterruptedException e) {
                e.printStackTrace(); } }
        else{
            while (true) {
                System.out.println(r.getEmiteur().getId()+" stay here");
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } } }
        r.getEmiteur().requeteServie(new RequeteReponse(r.getEmiteur(), r.getValeur())); }
}
