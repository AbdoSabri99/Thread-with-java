import java.util.Random;
public class Client implements  Runnable {
    private  int id;
    private static int cpt=1;
    private  static int clientsAcctifs=0;
    private Object o=new Object();
   // private ArrayBlockingQueue<Requete> rr;
    private Object mutex =new Object();
    private Serveur s;

    public Client(/*ArrayBlockingQueue<Requete> rr,*/ Serveur s) {
       // this.rr = rr;
        this.s = s;
        synchronized (mutex) {
            this.id = cpt++;
            clientsAcctifs++;
        }
    }

    public int getId() {
        return id;
    }

    public void requeteServie(RequeteReponse r) {
        System.out.println(r.toString()+" est bien servie");
        synchronized (o){
            o.notifyAll();
        }
    }
    @Override
    public void run() {
            for (int i = 0; i < 5; i++) {
                try {
                    System.out.println("Requst n "+i+" client "+this.id);
                    s.soumettre(new Requete(this, new Random().nextInt(100)));
                    System.out.println("j'attend le serveur");
                    synchronized (o){
                        o.wait();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            synchronized (mutex){
                clientsAcctifs--;
                if(clientsAcctifs==0){
                    System.out.println("moi le dernier donc je tue le serveur");
                    s.interput(); } }}
}
