import java.util.concurrent.ArrayBlockingQueue;
public class Serveur implements  Runnable{
    private ArrayBlockingQueue<Requete>  ra;
    private Object m=new Object();
    public Serveur(ArrayBlockingQueue<Requete>  r) {
        this.ra =r;
    }
    public void soumettre(Requete r) throws InterruptedException {
       ra.put(r);
    }
    public void traiterRequete() throws InterruptedException {
        Requete r=ra.take();
        new Thread(new Servant(r)).start();
    }
    @Override
    public void run() {
    while(true) {
        try {
            traiterRequete();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
 }
    public void interput() {
        Thread.currentThread().interrupt();
    }
}
