import java.util.Random;

public class RequeteReponse {
    private Client emiteur;
    private int val;
    private int ran;

    public RequeteReponse(Client emiteur, int val) {
        this.emiteur = emiteur;
        this.val = val;
        this.ran =new Random().nextInt(100);
    }
    public String toString(){
        return "Bienvenue,vous étes le client:"+emiteur.getId()+" votre numéro de requete est:"+val+" dont la reponse est:"+ran;
    }
}
