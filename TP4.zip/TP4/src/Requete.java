public class Requete {
    private Client emiteur;
    private int valeur;

    public Requete(Client emiteur, int valeur) {
        this.emiteur = emiteur;
        this.valeur = valeur;
    }
    public Requete(Requete r) {
        this.emiteur=r.emiteur;
        this.valeur=r.valeur;
    }

    public Client getEmiteur() {
        return emiteur;
    }

    public int getValeur() {
        return valeur;
    }
}
