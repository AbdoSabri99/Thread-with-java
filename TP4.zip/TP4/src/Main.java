import java.util.concurrent.ArrayBlockingQueue;

public class Main {
    public static void main(String[] args) throws InterruptedException {
            int taille=3;
            int nb_clients=4;
            ArrayBlockingQueue<Requete> req=new ArrayBlockingQueue<Requete>(taille,true);
            Serveur s=new Serveur(req);
            Thread t3=new Thread(s);
            t3.start();
            for (int i = 0; i < nb_clients; i++) {
                  new Thread(new Client(s)).start();
            }




    }
}
