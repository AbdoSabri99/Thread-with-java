public class Groupe implements Runnable{
   private int id;
   private int nb;
   private Salle s;

    public Groupe(int id, int nb, Salle s) {
        this.id = id;
        this.nb = nb;
        this.s = s;
    }

    public int getNb() {
        return nb;
    }

    @Override
    public void run() {
        if(s.reserver(id,nb)) {
            System.out.println(Thread.currentThread().getName()+" OK");
            return;
        }
        System.out.println(Thread.currentThread().getName()+" NOT OK");

    }
}
