
public class Main {
    public static void main(String[] args) throws InterruptedException {

        Salle s=new Salle(100,50);
        Groupe a=new Groupe(1,4000,s);
        Groupe b=new Groupe(2,900,s);
        Groupe c=new Groupe(3,100,s);
        Thread t1=new Thread(a);
        Thread t2=new Thread(b);
        Thread t3=new Thread(c);
        t1.start();
        t2.start();
        t3.start();
        t1.join();
        t2.join();
        t3.join();
        System.out.println("La taille de salle:"+s.getNbr()*s.getNbpr()+" places");
        System.out.println("Le nombre totales des places reservées:"+s.getPr());
        System.out.println("Le nombres disponibles dans la salle:"+s.placesdispo());
       int  nbr= a.getNb()+b.getNb()+c.getNb();
        System.out.println("Le nombre totales des membres des groupes:"+nbr);
    }
}
