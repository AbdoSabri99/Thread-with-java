public class Salle {
    private static int  pr;//pr:placeresrve
    private int nbr;//nbr:nbRangs
    private int nbpr;//nbpr:nbPlacesParRangs
    private boolean PL[][];
    public Salle(int nbr, int nbpr) {
        this.nbr = nbr;
        this.nbpr = nbpr;
        pr=0;
        PL=new boolean [nbr][nbpr];
        for (int i = 0; i <nbr ; i++) {
            for (int j = 0; j <nbpr ; j++) {
                PL[i][j]=false; } }
    }
    public int placesdispo(){
        return nbr*nbpr-pr;
    }

    public static int getPr() {
        return pr;
    }

    public int getNbr() {
        return nbr;
    }

    public int getNbpr() {
        return nbpr;
    }

    public boolean CapaciteOK(int n){
        if(placesdispo()>=n)
            return true;
        return false;
    }
    public int nContiguesAuRangsI(int n,int i){
        int nb=0;
        int j=0;
        if(CapaciteOK(n) && n<=nbpr){
          while (nb<n && j<nbpr){
                if (PL[i][j]==false) {
                    nb++; }
                else
                    nb=0;
                j++; } }
         if(nb==n)
             return j-n;
         else
                 return -1 ;
    }
    public  boolean reserverContigues(int id,int n)  {
        for (int i = 0; i <nbr ; i++) {
                if (nContiguesAuRangsI(n,i)!=-1){
                    int f=nContiguesAuRangsI(n,i);
                    int l=n+nContiguesAuRangsI(n,i);
                    for (int j =f; j <l; j++) {
                        PL[i][j]=true;
                        pr++; }
                    return true; } }
        return  false;
    }
    public  boolean reserver(int  id,int n) {
        if(CapaciteOK(n)) {
            if(reserverContigues(id, n))
                return true;
            else{
                for (int i = 0; i < nbr; i++) {
                    for (int j = 0; j <nbpr ; j++) {
                        if (PL[i][j] == false) {
                            PL[i][j] = true;
                            pr++;
                            n--;
                            if(n==0)
                                return true; }}}}}
               return  false; }
}

