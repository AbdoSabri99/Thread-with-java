public class CalculElement implements Runnable{
    private MaMatriceEntiere m1;
    private MaMatriceEntiere m2;
    private int i;
    private  int j;
    private static MaMatriceEntiere m;
    public CalculElement(MaMatriceEntiere m1, MaMatriceEntiere m2,int i,int j) {
        this.m1 = m1;
        this.m2 = m2;
        this.i=i;
        this.j=j;
        if(m==null)
            m=new MaMatriceEntiere(m1.getLignes(),m2.getColonnes(),0);
    }
    public void run() {
        try {
            m.setElement(i, j, MaMatriceEntiere.produitUneligneColonne(m1, i, m2, j));
            System.out.println("Fin de Calcul:");
        } catch (TaillesNonConcordantesException e) {
            e.printStackTrace();
        }
    }
    public static MaMatriceEntiere getM() {
        return m;
    }}
