public class ProduitParallele {
    public static void main(String[] args) throws TaillesNonConcordantesException, InterruptedException {
        MaMatriceEntiere t1=new MaMatriceEntiere(3,4,1);
        MaMatriceEntiere t2=new MaMatriceEntiere(4,3,1);
        System.out.println("la Matrice 1:");
        t1.printMatrice();
        System.out.println("la matrice 2:");
        t2.printMatrice();
        for (int i = 0; i < t1.getLignes() ; i++) {
            for (int j = 0; j < t2.getColonnes() ; j++) {
                CalculElement c=new CalculElement(t1,t2,i,j);
                Thread t=new Thread(c);
                t.start();
                t.join();
            }
        }
        System.out.println("le résultat du produit:");
        CalculElement.getM().printMatrice();
    }
}
